
@include('layouts.header')

<!-- Begin page -->
<div id="layout-wrapper">
    @include('layouts.hospital')

    <div class="main-content">

        <div class="page-content">

            <div class="container-fluid">
                <div class="page-title-box">

                    @if(session()->has('success'))

                    <div class="alert alert-success" role="alert">
                        <strong>Well done!</strong> {{session()->get('success')}}
                    </div>
                    @endif
                    @if(session()->has('error'))
                    <div class="alert alert-danger" role="alert">
                        <strong>Opps ! </strong> {{session()->get('error')}}
                    </div>
                    @endif

                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="page-title">Dashboard</h6>

                        </div>
                        @if (Auth::user()->role == 'admin')
                        <div class="col-md-4">
                            <div class="float-end d-none d-md-block">
                                <div class="dropdown">
                                    <a class="dropdown-item btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target=".bs-example-modal-center" href="#">Report Category</a>

                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>

                @if (Auth::user()->role == 'admin')

                <div class="modal fade bs-example-modal-center" tabindex="-1" role="dialog"
                    aria-labelledby="mySmallModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add Report Categoires</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">

                                                <form id="addUserForm" action="{{route('report.saveCategories')}}"
                                                    method="POST">
                                                    @csrf
                                                    <div class="row" style="    display: flex;
                                                justify-content: center;">
                                                        <div class=""
                                                            style="display: flex;    justify-content: center;">
                                                            <div class="mb-4 ml-2 gap-2" style="margin: 4px">
                                                                <label class="form-label" for="input-date1">Enter Report
                                                                    Categoires name</label>
                                                                <select id="category_name" class="form-control "
                                                                    type="text" name="report_type" name="" id="">
                                                                    <option value="">Select Report Category</option>
                                                                    <option value="blood_report">Blood Report</option>
                                                                    <option value="body_report">Body Report</option>
                                                                    <option value="ent">Others</option>
                                                                </select>
                                                                {{-- errors show --}}
                                                                @error('name')
                                                                {{$message}}
                                                                @enderror

                                                                <div id="error" class=" mb-0 mt-2">
                                                                </div>
                                                            </div>
                                                            <div class="mb-4" style="margin: 4px">
                                                                <label class="form-label" for="input-date1">Enter Report
                                                                    Categoires name</label>
                                                                <input id="category_name" class="form-control "
                                                                    type="text" name="name">

                                                                {{-- errors show --}}
                                                                @error('name')
                                                                {{$message}}
                                                                @enderror

                                                                {{-- <div id="error" class="alert alert-danger mb-0 mt-2">
                                                                </div> --}}
                                                            </div>
                                                        </div>
                                                        <button
                                                            class="btn btn-primary btn-lg w-100 waves-effect waves-light"
                                                            type="submit">Save</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>


                <div class="row">
                    <div class="col-xl-3 col-md-6">
                        <div class="card mini-stat bg-primary text-white">
                            <div class="card-body">
                                <div class="mb-4">
                                    <div class="float-start mini-stat-img me-4">
                                        <img src="assets/images/services-icon/01.png" alt="">
                                    </div>
                                    <h5 class="font-size-16 text-uppercase text-white-50">Users</h5>
                                    <h4 class="fw-medium font-size-24">
                                        {{$hospitals->count()}}
                                    </h4>

                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card mini-stat bg-primary text-white">
                            <div class="card-body">
                                <div class="mb-4">
                                    <div class="float-start mini-stat-img me-4">
                                        <img src="assets/images/services-icon/02.png" alt="">
                                    </div>
                                    <h5 class="font-size-16 text-uppercase text-white-50">Reports</h5>
                                    <h4 class="fw-medium font-size-24">{{$report_count}}</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card mini-stat bg-primary text-white">
                            <div class="card-body">
                                <div class="mb-4">
                                    <div class="float-start mini-stat-img me-4">
                                        <img src="assets/images/services-icon/02.png" alt="">
                                    </div>
                                    <h5 class="font-size-16 text-uppercase text-white-50">Prescription</h5>
                                    <h4 class="fw-medium font-size-24">{{$presecription}}
                                        {{-- <i
                                        class="mdi mdi-arrow-up text-success ms-2">
                                    </i> --}}
                                    </h4>

                                    {{--
                                <div class="mini-stat-label bg-info">
                                    <p class="mb-0"> 00%</p>
                                </div> --}}
                                </div>
                                {{-- <div class="pt-2">
                                <div class="float-end">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                                </div>

                                <p class="text-white-50 mb-0 mt-1">Since last month</p>
                            </div> --}}
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6">
                        <div class="card mini-stat bg-primary text-white">
                            <div class="card-body">
                                <div class="mb-4">
                                    <div class="float-start mini-stat-img me-4">
                                        <img src="assets/images/services-icon/04.png" alt="">
                                    </div>
                                    <h5 class="font-size-16 text-uppercase text-white-50">Total Report Categorires</h5>
                                    <h4 class="fw-medium font-size-24">{{$total_report_categorires}}
                                    </h4>
                                    {{-- <div class="mini-stat-label bg-warning">
                                    <p class="mb-0">+ 84%</p>
                                </div> --}}
                                </div>
                                {{-- <div class="pt-2">
                                <div class="float-end">
                                    <a href="#" class="text-white-50"><i class="mdi mdi-arrow-right h5"></i></a>
                                </div>

                                <p class="text-white-50 mb-0 mt-1">Since last month</p>
                            </div> --}}
                            </div>
                        </div>
                    </div>
                </div>
                @endif
                <!-- end row -->
                
                
                
                @include('admin.index')
                
            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->





    </div>
    <!-- end main content-->

</div>
<!-- END layout-wrapper -->



<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>

<!-- JAVASCRIPT -->
<script src="assets/libs/jquery/jquery.min.js"></script>
<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/libs/metismenu/metisMenu.min.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script>


<!-- Peity chart-->
<script src="assets/libs/peity/jquery.peity.min.js"></script>

<!-- Plugin Js-->
{{-- <script src="assets/libs/chartist/chartist.min.js"></script> --}}
{{-- <script src="assets/libs/chartist-plugin-tooltips/chartist-plugin-tooltip.min.js"></script> --}}

<script src="assets/js/pages/dashboard.init.js"></script>

<script src="assets/js/app.js"></script>



</body>



</html>