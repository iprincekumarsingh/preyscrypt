<iframe src="{{ url('/uploads/prescription/'.$pdf[0]["file_link"]) }}" width="100%" height="100%"
    frameborder="0"></iframe>