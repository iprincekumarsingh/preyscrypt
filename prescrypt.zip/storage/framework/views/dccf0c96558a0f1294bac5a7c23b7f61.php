<div class="table-responsive">
    <h1>
        Latest Users
    </h1>
    <table class="table mb-0">

        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Customer ID</th>
                <th>Phone</th>
                <th>DOB</th>
            </tr>
        </thead>
        <tbody>

            <?php

            $count = 0;
            $users = DB::table('users')
            ->where('role', 'user')
            ->orderBy('id', 'desc')->limit(5)->get();

            ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $count++;
            ?>
            <tr>
                <th scope="row"><?php echo e($count); ?></th>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->customer_id); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td><?php echo e($user->dob); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
        <!-- end tbody -->
    </table><!-- end table -->
</div>
<?php /**PATH C:\Users\Prince Kumar Singh\Desktop\project\prescrypt\resources\views/admin/index.blade.php ENDPATH**/ ?>