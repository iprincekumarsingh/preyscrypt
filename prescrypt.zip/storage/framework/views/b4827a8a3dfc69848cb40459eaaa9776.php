<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Begin page -->
<div id="layout-wrapper">
    <?php echo $__env->make('layouts.hospital', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-content">

        <div class="page-content">

            <div class="container-fluid">
                <div class="page-title-box">

                    <?php if(session()->has('success')): ?>

                    <div class="alert alert-success" role="alert">
                        <strong>Well done!</strong> <?php echo e(session()->get('success')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <strong>Opps ! </strong> <?php echo e(session()->get('error')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="row align-items-center">
                        <div class="col-md-8">


                        </div>
                        <?php if(Auth::user()->role == 'admin'): ?>

                        <?php endif; ?>
                    </div>
                </div>

                <?php if(Auth::user()->role == 'admin'): ?>
                <div class="card-body" style="border-bottom:1px solid black;margin-bottom:2px;padding:5px   ">

                    <h4 class="card-title">Upload Logo</h4>
                    <img src="" alt="" srcset="">

                    <div class="mb-5">
                        <form enctype="multipart/form-data" action="<?php echo e(route('admin.upload.logo')); ?>" method="POST" action="#">
                            <?php echo csrf_field(); ?>
                            <input type="file" name="file" id="">

                            <?php if($errors->has('file')): ?>
                            <div class="error" style="color:red">
                                <?php echo e($errors->first('file')); ?>

                            </div>

                            <?php endif; ?>

                            <button type="submit" class="btn btn-primary waves-effect waves-light">Upload</button>

                        </form><!-- end form -->
                    </div>


                </div>

                <?php endif; ?>
                <!-- end row -->





            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->





    </div>
    <!-- end main content-->

</div>
<!-- END layout-wrapper -->



<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>

<!-- JAVASCRIPT -->
<script src="assets/libs/jquery/jquery.min.js"></script>
<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/libs/metismenu/metisMenu.min.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script>


<!-- Peity chart-->
<script src="assets/libs/peity/jquery.peity.min.js"></script>

<!-- Plugin Js-->



<script src="assets/js/pages/dashboard.init.js"></script>

<script src="assets/js/app.js"></script>



</body>



</html><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\project\prescrypt\resources\views/admin/setting.blade.php ENDPATH**/ ?>