<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="navbar-brand-box">
        <a href="<?php echo e(route('home')); ?>" class="logo logo-dark">
            <span class="logo-sm">


                <?php
                $logo = App\Models\Setting::first();
                ?>
                <?php if($logo): ?>
                <img src="<?php echo e(asset('uploads/logo/'.$logo->logo)); ?>" alt="" height="22">
                <?php endif; ?>
            </span>
            <span class="logo-lg">
                <img src="<?php echo e(asset('uploads/logo/'.$logo->logo)); ?>" alt="" height="100px">
            </span>
        </a>

        <a href="<?php echo e(route('home')); ?>" class="logo logo-light">
            <span class="logo-sm">
                <img src="<?php echo e(asset('uploads/logo/'.$logo->logo)); ?>" alt="" height="22">
            </span>
            <span class="logo-lg">
                <img src="<?php echo e(asset('uploads/logo/'.$logo->logo)); ?>" alt="" height="18">
            </span>
        </a>
    </div>
    <div id="layout-wrapper">
        <div class="main-contet">
            <div class="page-content" style="padding:0px">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!-- Page title -->


                            <div class="my-5">
                                <h3>Update Profile</h3>
                                <hr>
                            </div>
                            <!-- Form START -->
                            <form class="file-upload" action="<?php echo e(route('user.update_profile')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class=" row mb-5 gx-5">
                                    <!-- Contact detail -->
                                    <div class="col-xxl-8 mb-5 mb-xxl-0">
                                        <div class="bg-secondary-soft px-4 py-5 rounded">
                                            <div class="row g-3">

                                                
                                                
                                                <?php if(session('success')): ?>
                                                <div class="alert alert-success  show" role="alert">
                                                    <strong><?php echo e(session('success')); ?></strong>

                                                </div>
                                                <?php endif; ?>
                                                <!-- First Name -->
                                                <div class="col-md-6">
                                                    <label class="form-label"> Name *</label>
                                                    <input name="name" type="text" class="form-control" placeholder=""
                                                        aria-label="First name" value="<?php echo e(Auth::user()->name); ?>">
                                                </div>
                                                <!-- Last name -->
                                                
                                                <!-- Phone number -->
                                                <div class="col-md-6">
                                                    <label class="form-label">Phone number *</label>
                                                    <input type="text" class="form-control" placeholder=""
                                                        aria-label="Phone number" value="<?php echo e(Auth::user()->phone); ?>">
                                                </div>
                                                <!-- Mobile number -->
                                                
                                                <!-- Email -->
                                                <div class="col-md-6">
                                                    <label for="inputEmail4" class="form-label">Email *</label>
                                                    <input name="email" type="email" class="form-control"
                                                        id="inputEmail4" value="<?php echo e(Auth::user()->email); ?>">
                                                </div>
                                                <!-- Skype -->
                                                <div class="col-md-6">
                                                    <label class="form-label">Date of Birth *</label>
                                                    <input name="dob" type="date" class="form-control" placeholder=""
                                                        aria-label="Phone number" value="<?php echo e(Auth::user()->dob); ?>">
                                                </div>
                                            </div> <!-- Row END -->
                                        </div>
                                    </div>

                                </div> <!-- Row END -->


                                <!-- button -->
                                <div class="gap-3 mb-3 d-md-flex justify-content-md-end text-center">
                                    
                                    <button type="submit" class="btn btn-primary btn-lg">Update profile</button>
                                </div>
                            </form> <!-- Form END -->
                        </div>
                    </div>
                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->





        </div>
        <!-- end main content-->

    </div>


    <!-- JAVASCRIPT -->
    <script src="assets/libs/jquery/jquery.min.js"></script>
    

    

    <!-- form wizard -->
    <script src="assets/libs/jquery-steps/build/jquery.steps.min.js"></script>

    <!-- form wizard init -->
    <script src="assets/js/pages/form-wizard.init.js"></script>

    <script src="assets/js/app.js"></script>

</body>

</html><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\project\prescrypt\resources\views/user/new_user.blade.php ENDPATH**/ ?>