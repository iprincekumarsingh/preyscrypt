<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Begin page -->
<div id="layout-wrapper">



    <?php echo $__env->make('layouts.hospital', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Left Sidebar End -->
    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="main-content">

        <div class="page-content">

            <div class="container-fluid">

                <!-- start page title -->
                <div class="page-title-box">

                    <?php if(session()->has('success')): ?>

                    <div class="alert alert-success" role="alert">
                        <strong>Well done!</strong> <?php echo e(session()->get('success')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="page-title">Report Category</h6>
                            <ol class="breadcrumb m-0">
                                
                            </ol>
                        </div>
                        <div class="col-md-4">
                            <div class="float-end d-none d-md-block">
                                <div class="dropdown">
                                    <div class="dropdown">
                                        <a class="btn btn-primary" data-bs-toggle="modal"
                                            data-bs-target=".bs-example-modal-center" href="#">Add Report Category</a>
    
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end page title -->

                <div class="modal fade bs-example-modal-center" tabindex="-1" role="dialog"
                aria-labelledby="mySmallModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Report Categoires</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">

                                            <form id="addUserForm" action="<?php echo e(route('report.saveCategories')); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="row" style="    display: flex;
                                            justify-content: center;">
                                                    <div class=""
                                                        style="display: flex;    justify-content: center;">
                                                        <div class="mb-4 ml-2 gap-2" style="margin: 4px">
                                                            <label class="form-label" for="input-date1">Enter Report
                                                                Categoires name</label>
                                                            <select id="category_name" class="form-control "
                                                                type="text" name="report_type" name="" id="">
                                                                <option value="">Select Report Category</option>
                                                                <option value="blood_report">Blood Report</option>
                                                                <option value="body_report">Body Report</option>
                                                                <option value="ent">Others</option>
                                                            </select>
                                                            
                                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                            <div id="error" class=" mb-0 mt-2">
                                                            </div>
                                                        </div>
                                                        <div class="mb-4" style="margin: 4px">
                                                            <label class="form-label" for="input-date1">Enter Report
                                                                Categoires name</label>
                                                            <input id="category_name" class="form-control "
                                                                type="text" name="name">

                                                            
                                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                            
                                                        </div>
                                                    </div>
                                                    <button
                                                        class="btn btn-primary btn-lg w-100 waves-effect waves-light"
                                                        type="submit">Save</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
                
                <div class="table-responsive">
                    <table class="table mb-0">

                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Category Name</th>
                                <th>Delete</th>
                               
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row">1</th>
                                <td><?php echo e($category->name); ?></td>
                                <td class=""><span class="
                                    alert alert-danger danger" style="text-align: ">Delete <i style="width: 30px" class="ion ion-md-trash"></i>
                                    </span> </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                            
                        </tbody>
                        <!-- end tbody -->
                    </table><!-- end table -->
                </div>


            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->





    </div>
    <!-- end main content-->

</div>
<!-- END layout-wrapper -->



<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>

<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>



<!-- Plugin Js-->



<script src="<?php echo e(asset('assets/js/pages/dashboard.init.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>



</body>



</html><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\project\prescrypt\resources\views/web/reportCategories.blade.php ENDPATH**/ ?>