<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet')); ?>"
    type="text/css">
<link href="<?php echo e(asset('assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet"
    type="text/css">

<!-- Responsive datatable examples -->
<link href="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet"
    type="text/css">

<!-- Begin page -->
<div id="layout-wrapper">



    <?php echo $__env->make('layouts.hospital', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Left Sidebar End -->
    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="page-title-box">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="page-title">Registered Users</h6>
                            <?php if(session()->has('success')): ?>

                            <div class="alert alert-success" role="alert">
                                <strong>Well done!</strong> <?php echo e(session()->get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <strong>Opps ! </strong> <?php echo e(session()->get('error')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <?php if(Auth::user()->role=="admin"): ?>
                        <div class="col-md-4">
                            <div class="float-end d-md-block">
                                <div class="dropdown">
                                    <a class="btn btn-primary  " type="button" data-bs-toggle="modal"
                                        data-bs-target=".bs-example-modal-center" href="#">
                                        Add User(Hospital)
                                    </a>

                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- end page title -->

                <div class="modal fade bs-example-modal-center" tabindex="-1" role="dialog"
                    aria-labelledby="mySmallModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add User</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div class="card-body">

                                                <form id="addUserForm" action="<?php echo e(route('admin.user.add')); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="row" style="    display: flex;
                                            justify-content: center;">
                                                        <div class=",b-4"
                                                            style="display: flex;    justify-content: center;">
                                                        </div>
                                                        <div class="mb-4 ml-2 gap-2" style="margin: 4px">
                                                            <label class="form-label" for="input-date1">Enter
                                                                Role</label>
                                                            <select id="category_name" class="form-control " type="text"
                                                                name="role" id="">
                                                                <option value="">Select Role</option>
                                                                <option value="user">USER</option>
                                                                <option value="hospital">HOSPITAL</option>
                                                                <option value="admin">Admin</option>
                                                            </select>
                                                            
                                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                            <div id="error" class=" mb-0 mt-2">
                                                            </div>
                                                        </div>
                                                        <div class="mb-4" style="margin: 4px">
                                                            <label class="form-label" for="input-date1">Enter
                                                                Name</label>
                                                            <input id="category_name" class="form-control " type="text"
                                                                name="name">

                                                            
                                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                            
                                                        </div>
                                                        <div class="mb-4" style="margin: 4px">
                                                            <label class="form-label" for="input-date1">Enter
                                                                Phone</label>
                                                            <input id="category_name" class="form-control " type="text"
                                                                name="phone">

                                                            
                                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                            
                                                        </div>
                                                        <button
                                                            class="btn btn-primary btn-lg w-100 waves-effect waves-light"
                                                            type="submit">Save</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">


                                <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">

                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Customer ID</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>DOB</th>
                                            <th>Tools</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->customer_id); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo e($user->phone); ?></td>
                                            <td><?php echo e($user->dob); ?></td>
                                            <td>
                                                
                                                <a style="letter-spaceing:2px"
                                                    href="<?php echo e(route('hospital.user.profile',$user->id)); ?>"><i
                                                        class="fas fa-eye    "></i>
                                                    View</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->

            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->


       


    </div>
    <!-- end main content-->

</div>
</div>
</div>


</div>
<!-- end main content-->

</div>
<!-- END layout-wrapper -->




<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>
<!-- Responsive examples -->
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>">
</script>

<!-- Datatable init js -->
<script src="<?php echo e(asset('assets/js/pages/datatables.init.js')); ?>"></script>

<!-- Plugin Js-->



<script src="<?php echo e(asset('assets/js/pages/dashboard.init.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>



</body>



</html><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\project\prescrypt\resources\views/web/userlist.blade.php ENDPATH**/ ?>