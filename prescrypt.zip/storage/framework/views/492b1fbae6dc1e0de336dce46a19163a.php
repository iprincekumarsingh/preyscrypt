<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet')); ?>"
    type="text/css">
<link href="<?php echo e(asset('assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet"
    type="text/css">

<!-- Responsive datatable examples -->
<link href="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet"
    type="text/css">
</head>


<body data-topbar="light" data-layout="horizontal" data-layout-size="boxed">
    <!-- Begin page -->
    <div id="layout-wrapper">


        <?php echo $__env->make('layouts.user_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-content">
            <div class="col-sm-6 col-md-4 col-xl-3">
                <div class="my-4 text-center">
                    <p class="text-muted">Center modal</p>
                    <!-- Small modal -->

                </div>

                <div class="modal fade bs-example-modal-center" tabindex="-1" role="dialog"
                    aria-labelledby="mySmallModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Upload Report</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="fileUploadForm" method="POST" action="<?php echo e(url('/upload_report')); ?>"
                                    enctype="multipart/form-data" class="form-horizontal form-wizard-wrapper">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">

                                        <div class="col-md- ">
                                            <div class="row mb-3" style="display: flex;justify-content:center">

                                                <div class="col-lg-9">
                                                    <label for="">Choose Report</label>
                                                    <input name="file" type="file" class="form-control" id="resume">
                                                </div>
                                                <span>
                                                    <h4 style="display:block;color:red" id="error_messaage">
                                                        </h1>
                                                </span>


                                                <input type="hidden" name="category_id"
                                                    value="<?php echo e($report_catgoires[0]['id']); ?>">
                                                <input type="hidden" name="category_upload"
                                                    value="<?php echo e($report_catgoires[0]['name']); ?>">






                                                <!-- end col -->
                                            </div>
                                        </div>
                                        <!-- end col -->
                                    </div>
                                    <div class="form-group mb-3">
                                        <div class="progress">
                                            <div id="upload_status"
                                                class="progress-bar progress-bar-striped progress-bar-animated bg-success"
                                                role="progressbar" aria-valuenow="0" aria-valuemin="0"
                                                aria-valuemax="100" style="width: 0%"></div>
                                        </div>
                                    </div>
                                    <button class="btn btn-primary btn-lg w-100 waves-effect waves-light"
                                        type="submit">Upload Report</button>
                                    <!-- end col -->
                            </div>
                            <!-- end row -->

                            </fieldset>


                            </form>
                        </div>
                    </div>


                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
            <!-- /.modal -->
        </div>

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="page-title-box">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="page-title">Report - <?php echo e($report_catgoires[0]['name']); ?></h6>

                        </div>
                        <div class="col-md-4">
                            <div class="float-end  d-md-block">
                                <div class="dropdown">
                                    <button class="btn btn-primary  dropdown-toggle" type="button"
                                        id="dropdownMenuButton" data-bs-toggle="modal"
                                        data-bs-target=".bs-example-modal-center" aria-expanded="false">
                                        <i class="fas fa-cloud-upload-alt me-2"></i> Upload Report
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a class="dropdown-item" href="#">Action</a>
                                        <a class="dropdown-item" href="#">Another action</a>
                                        <a class="dropdown-item" href="#">Something else here</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="#">Separated link</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end page title -->



                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">


                                <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">

                                    <thead>
                                        <tr>

                                            <th>Report Name</th>
                                            <th>Document Number</th>
                                            <th>Upload At</th>

                                            <th>Tools</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        <?php $__currentLoopData = $user_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($item->DocumentType); ?></td>
                                            <td><?php echo e($item->DocumentNumber); ?></td>
                                            

                                            <td><?php echo e($item->created_at->format(' d / M  / Y ')); ?></td>


                                            <td>

                                                <a style="letter-spaceing:2px"
                                                    href="<?php echo e(route('user.pdf',$item->DocumentNumber)); ?>"><i
                                                        class="fas fa-eye    "></i>
                                                    View Report</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->

            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->




    </div>
    <!-- end main content-->

    </div>
    </div>
    </div>


    </div>

    </div>
    <!-- end main content-->

    </div>


    <!-- JAVASCRIPT -->
    <!-- JAVASCRIPT -->
    <script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>
    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>">
    </script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('assets/js/pages/datatables.init.js')); ?>"></script>

    <!-- Plugin Js-->
    
    

    <script src="<?php echo e(asset('assets/js/pages/dashboard.init.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/form.min.js')); ?>"></script>
    <script>
        $(function () {
            $(document).ready(function () {
                $('#fileUploadForm').ajaxForm({
                    beforeSend: function () {
                        var percentage = '0';
                    },
                    uploadProgress: function (event, position, total, percentComplete) {
                        var percentage = percentComplete;
                        $('.progress .progress-bar').css("width", percentage+'%', function() {
                          return $(this).attr("aria-valuenow", percentage) + "%";
                        })
                      
                    },
                    complete: function (xhr) {
                      console.log(xhr.responseJSON.message);

                    
                        $('#error_messaage').text(xhr.responseJSON.message);
                        
                        // window.location.reload();
                        location.reload()
                    }
                    
                    
                });
            });
        });
    </script>

</body>


</html><?php /**PATH C:\Users\Prince Kumar Singh\Desktop\project\prescrypt\resources\views/user/report_category.blade.php ENDPATH**/ ?>