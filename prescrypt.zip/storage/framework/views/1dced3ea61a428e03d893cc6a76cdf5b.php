<iframe src="<?php echo e(url('/uploads/prescription/'.$pdf[0]["file_link"])); ?>" width="100%" height="100%"
    frameborder="0"></iframe>
    <?php /**PATH C:\Users\Prince Kumar Singh\Desktop\project\prescrypt\resources\views/user/prescriptions_view.blade.php ENDPATH**/ ?>